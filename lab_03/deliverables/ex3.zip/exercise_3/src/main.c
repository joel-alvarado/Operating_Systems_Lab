#include "thread_routines.h"

int main(void) { startThreads(); }