#include "ball.h"

int main() { startBouncingBall(); }