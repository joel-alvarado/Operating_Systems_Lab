#include "tangent_calculator.h"

int main(void) { compareTimeTaken(); }