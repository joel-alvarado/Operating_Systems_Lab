#include "asin_calc_threading.h"

int main(void) { launchAsinCalculator(); }