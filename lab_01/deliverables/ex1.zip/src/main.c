#include "guessing_game.h"

int main() { GuessingGame(true); }