# How to use

First, execute `exercise_1` from the `build` folder. This will fork the process 3 times, and each fork will run 2 new instances of the `greetings` executable. This means there will be 6 `greetings` running at once. This can be appreciated in the screnshot `pstree_output.png`. 