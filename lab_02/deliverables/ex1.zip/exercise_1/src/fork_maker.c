#include <sys/types.h>
#include <unistd.h>

#include "child_creator.h"

int main() { CreateChildren(3); }