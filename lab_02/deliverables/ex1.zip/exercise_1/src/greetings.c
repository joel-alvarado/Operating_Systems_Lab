#include "greetlib.h"

int main() { PrintGreetings(); }