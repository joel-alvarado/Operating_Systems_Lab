#ifndef GREETLIB_H
#define GREETLIB_H

/**
 * @brief Prints the current PID and sleeps for 10 seconds. Then says goodbye.
 *
 */
void PrintGreetings();

#endif /* GREETLIB_H */