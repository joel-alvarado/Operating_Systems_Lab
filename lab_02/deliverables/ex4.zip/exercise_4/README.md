# How to use

You can execute `exercise_4` from the `build` folder. This will run and compare the shared memory method vs message queues method to do the following:
- Process A will write numbers 1 to 1000000
- Process B will sum the numbers and print it out.

The program times both of these methodologies and compares the execution time of each.