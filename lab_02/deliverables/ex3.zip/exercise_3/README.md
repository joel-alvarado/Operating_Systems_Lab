# How to use

First, execute `exercise_3` binary in the `build` folder. You will be prompted for the amount of processes to spawn. After, each process will print to the current shell. You may then open a separate shell and execute `counter_handler <amount>` from the `build` folder with amount being the same amount of counters you spawned.