#include <stdio.h>

int main() { fprintf(stdout, "Hello from hello.c!\n"); }