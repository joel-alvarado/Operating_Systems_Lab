
# How to use
Welcome to simple shell! To start, execute `exercise_2` from the `build` folder. Most of the basic bash commands work here. Things that do not work:
- environment variables, ~ operator, pipes
- operators ||, >, etc

Program execution is enabled. Use syntax `./<bin>`
You can use `cd` to exit out of the build directory.